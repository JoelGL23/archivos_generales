library(sf)

archivo_mun <- "1_datos/mapa_mexico_municipios/01_32_mun.shp"
archivo_es <- "1_datos/mapa_mexico_estados/Mexico_States.shp"

if (file.exists(archivo_mun) & file.exists(archivo_es)){
  
  # Carga el archivo shapefile a R
  mex_map_mun <- st_read("1_datos/mapa_mexico_municipios/01_32_mun.shp")
  mex_map_es <- st_read("1_datos/mapa_mexico_estados/Mexico_States.shp")
  
}else{
  
  # Crear carpeta donde descargar el archivo
  dir.create("1_datos/mapa_mexico_municipios")
  
  # Descarga el archivo zip de github
  download.file(url = "https://github.com/prestevez/covid-19-mx-map/raw/master/datos_covid/01_32_mun.zip",
                destfile = "1_datos/mapa_mexico_municipios/01_32_mun.zip")
  
  # Extrae el archivo zip en la carpeta datos_covid
  unzip("1_datos/mapa_mexico_municipios/01_32_mun.zip", exdir = "1_datos/mapa_mexico_municipios/")
  
  # Descarga el archivo zip de github
  download.file(url = "https://github.com/JoelGL23/archivos_generales/raw/main/mapa_mexico_estados.zip",
                destfile = "1_datos/mapa_mexico_estados.zip")
  
  unzip("1_datos/mapa_mexico_estados.zip", exdir = "1_datos/")
  
  source("2_r_scripts/carga_mapa.R")
  
}

mex_map_es$CODE <- gsub("MX","",mex_map_es$CODE)