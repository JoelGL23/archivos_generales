download.file(url = "https://github.com/JoelGL23/archivos_generales/raw/main/OpenEyesMex.zip",
              destfile = "OpenEyesMex/OpenEyesMex.zip")

unzip("OpenEyesMex/OpenEyesMex.zip", exdir = "OpenEyesMex/")